#include "Game.h"

int main() {
	Game game = Game();
	game.start();
	return 0;
}
